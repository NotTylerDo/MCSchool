
public enum Type {
	SMOOTHIE, COFFEE, ALCOHOL;
}
